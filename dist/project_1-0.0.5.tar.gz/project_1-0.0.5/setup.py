import setuptools

setuptools.setup(
    name="project_1",
    version="0.0.5",
    author="Ankit Sakhuja",
    description="A package for helper function, with json "
                "message path added",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIt License",
        "Operating System :: OS Independent",


    ],
    packages=['test_package'],
    python_requires='>3.5',

)
