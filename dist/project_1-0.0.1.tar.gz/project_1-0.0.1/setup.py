import setuptools

setuptools.setup(
    name="project_1",
    version="0.0.1",
    author="Ankit Sakhuja",
    description="A package for helper function",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIt License",
        "Operating System :: OS Independent",


    ],
    packages=['E:\gitdemo\project_1'],
    python_requires='>3.5',

)
