def print_func(name):
    return f" my name is  {name}"


def add(a, b):
    return a + b
