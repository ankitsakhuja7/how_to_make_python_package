def print_func(name):
    return f" my name is  {name}"


def add(a, b):
    return a + b


def messages_json_path():
    return 'test_package/example.json'
